
public class Song {
	
	String title;
	String artist;
	String album;
	String[] composer;
	int year;
	int track;
	
	public Song(String title, String artist, String album, String[] composer, int year,int track)
	{
		this.title =title;
		this.artist= artist;
		this.album=album;
		for(int i=0;i<composer.length;i++)
		{
			this.composer=composer;
		}
		this.year=year;
		this.track=track;
	}
	
	public void show(){
		System.out.println("title is " +title);
		System.out.println("artist is " +artist);
		System.out.println("album is " +album);
		System.out.println("composer is ");
		for(int i=0;i<composer.length;i++)
		{
			System.out.print(composer[i]);
			if(i>=0 && i < composer.length-1)
			{
			 System.out.print(", ");
			}
		}
		System.out.println();
		System.out.println("Year is : "+year);
		System.out.println("Track number is : "+track);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Song DancingQueen = new Song("Dancing Queen","HyunIll","Arrival",new String[]{"Benny Andersson","Bjorn Ulvaeus"}, 1977, 2);
		DancingQueen.show();
	}

}
