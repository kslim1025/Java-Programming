import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

class WindowEventhandler implements WindowListener //class implements를 붙이면 안에 메인문을 넣을 수 없
{
	String frameInfo;
	
	public WindowEventhandler(String info)
	{
		frameInfo=info;
	}	
	public void windowActivated(WindowEvent e)
	{
		System.out.println(frameInfo +" windowActivated");
	}
	public void windowClosed(WindowEvent e)
	{
		System.out.println(frameInfo+"windowClosing");
	}
	public void windowClosing(WindowEvent e)
	{
		JFrame frm=(JFrame)e.getWindow();
		frm.dispose();
		System.out.println(frameInfo+"windowClosing");
	}
	public void windowDeactivated(WindowEvent e)
	{
		System.out.println(frameInfo+"windowDeactivated");
	}	
	public void windowDeiconified(WindowEvent e)
	{
		System.out.println(frameInfo+"windowDeiconified");
	}
	public void windowIconified(WindowEvent e)
	{
		System.out.println(frameInfo+"windowIconified");
	}
	public void windowOpened(WindowEvent e)
	{
		System.out.println(frameInfo+"windowOpened");
	}
}

class JFrameWindowEvent {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			JFrame frmOne = new JFrame("Frame One");
			JFrame frmTwo = new JFrame("Frame Two");
			
			frmOne.setBounds(120,120,250,150);
			frmTwo.setBounds(120,120,250,150);
			
			frmOne.addWindowListener(new WindowEventhandler("Frame One"));
			frmTwo.addWindowListener(new WindowEventhandler("Frame Two"));
			
			frmOne.add(new JButton("Button One"));
			frmTwo.add(new JButton("Button Two"));
			frmOne.setVisible(true);
			frmTwo.setVisible(true);
			
	}
}