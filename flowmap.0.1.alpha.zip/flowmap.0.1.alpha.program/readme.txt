This is the program that implements some of the functionality for the paper:

Flow Map Layout
by Doantam Phan, Ling Xiao, Ron Yeh, Terry Winograd, and Pat Hanrahan
InfoVis 2005.

Source code by:
Doantam Phan - http://graphics.stanford.edu/~dphan
Ling Xiao - http://graphics.stanford.edu/~lingxiao
Ron Yeh - http://graphics.stanford.edu/~ronyeh


If you find this code useful, feel free to send me an image of
something cool (or not, no worries) in your hometown to the email
address at http://graphics.stanford.edu/~dphan/code/bsd.license.html

Thanks!
