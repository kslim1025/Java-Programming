
public class ArrayConcat 
{
	static int[] concat(int[] a1, int[] a2) 
	{
		int[] connectArray = new int[(a1.length) + (a2.length)];
		for (int i = 0; i < a1.length; i++) 
		{
			connectArray[i] = a1[i];
		}
		for (int i = a1.length; i < (a1.length) + (a2.length); i++) 
		{
			connectArray[i] = a2[i-(a1.length)];
		}
		return connectArray;
	}

	static int[] remove(int[] a1, int a2[]) 
	{
		int[] removeArray = new int[(a1.length) - (a2.length)];
		for (int i = 0; i < (a1.length) - (a2.length); i++)
		{
			removeArray[i] = a1[i];
		}
		return removeArray;
	}
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		int[] Array1 = { 1, 2, 3, 4, 5 };
		int[] Array2 = { 6, 7, 8, 9, 10, 11, 12 };

		int[] connectArray = concat(Array1, Array2);
		System.out.println("Connect Array");
		for (int i = 0; i < connectArray.length; i++) 
		{
			System.out.println(connectArray[i] + "\t");
		}
		System.out.println();
		int[] removeArray = remove(connectArray, Array2);
		System.out.println("Delete Array");
		for (int i = 0; i < removeArray.length; i++) 
		{
			System.out.println(removeArray[i] + "\t");
		}
	}
}
