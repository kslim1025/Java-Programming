import java.util.*;

public class EngilshCount 
{
	public static void main(String[] args) {
	Scanner in = new Scanner(System.in);
	String str;
	int n = 0;
	
	System.out.print("영문자를 입력하세요>>");
	try 
	{
		while(true) 
		{
			str = in.nextLine();

			for(int i=0; i<str.length(); i++)
			{
				if(str.charAt(i) >= 'A' && str.charAt(i)<='Z')
				n++;
			}
		}
	}
	catch (NoSuchElementException e) 
	{
		System.out.println("대문자의 개수는 " + n);
	} 
   }
  }
