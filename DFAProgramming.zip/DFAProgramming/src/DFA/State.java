package DFA;

public class State
{
    private String name;
    private boolean isTerminal;
   
    public State(String name)
    {
        this(name, false);
    }
   
    public State(String name, boolean isTerminal)
    {
        if(name == null) {
            throw new IllegalArgumentException("name is null!!");
        }
       
        this.name = name;
        this.isTerminal = isTerminal;
    }
   
    public void setTerminal()
    {
        isTerminal = true;
    }
   
    public void setNonTerminal()
    {
        isTerminal = false;
    }
   
    public boolean isTerminal()
    {
        return isTerminal;
    }
   
    public String getName()
    {
        return name;
    }
   
    public String toString()
    {
        return "{State,name=" + name + ",isTerminal=" + isTerminal + "}";
    }
}