package DFA;


/*5 1 3 -1
2 a b
1 -1 2 4 -1 3 2 -1 1 0
 
와 같은 input.txt 파일을 읽어들여서
DFA 전이표를 만드는 프로그램입니다.
5(상태의 갯수) 1 3(1,3이 끝) -1(최종상태 -1=종료)
2(입력심볼의 갯수) a b(심볼a,b)
(1 -1) (2 4) (-1 3) (2 -1) (1 0) 5개의 상태
 
출력 결과물
ab
0         1           -
1         2           4
2         -           3
3         2           -
4         1           0
Enter the input :
 
여기까지 출력되고
aabaa 이런식으로 임의의 상태이동을 입력하면
aabaa        0-1-2-3-2-(-1) false
 
aba
aba            0-1-4-1 true*/

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DFA dfa = new DFA("5 1 3 -1", "2 a b","1 -1 2 4 -1 3 2 -1 2 4 -1 3 2 -1 1 0");
		
		dfa.print();
		
		System.out.println();
		
		String word = "aabaa";
		System.out.println(word + "\t" + dfa.trace(word) + " " + dfa.accept(word));
		word = "aba";
	    System.out.println(word + "\t" + dfa.trace(word) + " " + dfa.accept(word));
	}

}
