package DFA;
import java.util.HashMap;

public class DFA
{
    private State[] __stateArray;
    private State   __startState, __endState;
    private Symbol[] __symbolArray;
 
    private HashMap<String, State>  __hashState;
    private HashMap<String, Symbol> __hashSymbol;
    private HashMap<String, State>  __hashTransRule;
    
    public DFA(String stateStr, String symbolStr, String transStr)
    {
        this(stateStr.trim().split("\\p{Space}"),
             symbolStr.trim().split("\\p{Space}"),
             transStr.trim().split("\\p{Space}"));
    }
   
    public DFA(String[] arrState, String[] arrSymbol, String[] arrTransRule)
    {
        __hashState = new HashMap<String, State>();
       
        int statecount = Integer.parseInt(arrState[0]);
       
        if(statecount < 1) {
            throw new IllegalArgumentException("blah blah blah...1");
        }
       
        __stateArray = new State[statecount];
       
        for(int i = 0 ; i < statecount ; i++) {
            State state = new State(String.valueOf(i));
           
            __stateArray[i] = state;
            __hashState.put(String.valueOf(i), state);
        }
       
        for(int i = 1 ; i < arrState.length - 1 ; i++) {
            __hashState.get(arrState[i]).setTerminal();
        }
       
        __startState = __stateArray[0];
       
        String terminateStr = arrState[arrState.length - 1];
       
        __endState = new State(terminateStr);
       
        __hashState.put(terminateStr, __endState);
       
        __hashSymbol = new HashMap<String, Symbol>();
       
        int symbolcount = Integer.parseInt(arrSymbol[0]);
        __symbolArray = new Symbol[symbolcount];
       
        for(int i = 1 ; i <= symbolcount ; i++) {
            Symbol symbol = new Symbol(arrSymbol[i]);
 
            __symbolArray[i - 1] = symbol;
            __hashSymbol.put(arrSymbol[i], symbol);
        }
       
        if(arrTransRule.length % __symbolArray.length > 0) {
            throw new IllegalArgumentException("blah blah blah...2");
        }
       
        __hashTransRule = new HashMap<String, State>();
       
        int arrSymbolSize = __symbolArray.length;
       
        for(int i = 0, size = __stateArray.length ; i < size ; i++) {
            for(int j = 0 ; j < arrSymbolSize ; j++) {
                if(!__hashState.containsKey(arrTransRule[i * arrSymbolSize + j])) {
                    throw new IllegalArgumentException("blah blah blah...3");
                }
               
                StateSymbolPair pair = new StateSymbolPair(__stateArray[i], __symbolArray[j]);
                State state = __hashState.get(arrTransRule[i * arrSymbolSize + j]);
               
                __hashTransRule.put(pair.getKey(), state);
            }
        }
    }
   
    public State nextState(State state, Symbol symbol)
    {
        return this.nextState(new StateSymbolPair(state, symbol));
    }
   
    private State nextState(StateSymbolPair pair)
    {
        if(!__hashTransRule.containsKey(pair.getKey())) {
            throw new IllegalArgumentException("blah blah blah...4");
        }
       
        return __hashTransRule.get(pair.getKey());
    }
   
    public boolean accept(String word)
    {
        char[] arrAlphabet = word.toCharArray();
        State state = __startState;
       
        for(int i = 0, size = arrAlphabet.length ; i < size ; i++) {
            state = nextState(state, __hashSymbol.get(String.valueOf(arrAlphabet[i])));
           
            if(state.equals(__endState)) {
                break;
            }
        }
       
        return state.isTerminal();
    }
   
    public String trace(String word)
    {
        char[] arrAlphabet = word.toCharArray();
        State state = __startState;
       
        StringBuffer sb = new StringBuffer();
        sb.append("-[").append(state.getName()).append("]");
       
        for(int i = 0, size = arrAlphabet.length ; i < size ; i++) {
            state = nextState(state, __hashSymbol.get(String.valueOf(arrAlphabet[i])));
           
            sb.append("-[").append(state.getName()).append("]");
           
            if(state.equals(__endState)) {
                break;
            }
        }
       
        return sb.toString().substring(1);
    }
   
    public void print()
    {
        for(int i = 0 ; i < __symbolArray.length ; i++) {
            System.out.print("\t");
            System.out.print(__symbolArray[i].getSymbol());
        }
       
        System.out.println();
 
        for(int i = 0 ; i < __stateArray.length ; i++) {
            System.out.print(__stateArray[i].getName());
            System.out.print("\t");
           
            for(int j = 0 ; j < __symbolArray.length ; j++) {
                StateSymbolPair pair = new StateSymbolPair(__stateArray[i], __symbolArray[j]);
                State nextState = __hashTransRule.get(pair.getKey());
               
                System.out.print(nextState == __endState ? "-" : nextState.getName());
                System.out.print("\t");
            }
           
            System.out.println();
        }
    }
   
    private class StateSymbolPair
    {
        private State __state;
        private Symbol __symbol;
       
        StateSymbolPair(State currentState, Symbol inputSymbol)
        {
            this.__state = currentState;
            this.__symbol = inputSymbol;
        }
       
        public String toString()
        {
            return "{StateSymbolPair,State=" + __state.toString() +
                   ",Symbol=" + __symbol.toString() + "}";
        }
       
        String getKey()
        {
            return this.toString();
        }
       
        State getState()
        {
            return this.__state;
        }
       
        Symbol getSymbol()
        {
            return this.__symbol;
        }
    }
}