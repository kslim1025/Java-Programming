package DFA;

public class Symbol
{
    private String symbol;
   
    public Symbol(String symbol)
    {
        if(symbol == null) {
            throw new IllegalArgumentException("symbol is null!!");
        }
       
        this.symbol = symbol;
    }
   
    public String getSymbol()
    {
        return symbol;
    }
   
    public String toString()
    {
        return "{Symbol,Symbol=" + symbol + "}";
    }
}
 