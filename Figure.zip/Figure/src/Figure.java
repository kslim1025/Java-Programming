class Circle
{
	int x;
	int y;
	int radius;
	
	public Circle(int x, int y, int radius)
	{
		this.x= x;
		this.y= y;
		this.radius = radius;
		
	}
	public boolean equals(Circle k){
		if(this.radius == k.radius)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
public class Figure {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Circle a = new Circle(10,20, Math.abs(10-20));
		Circle b = new Circle(30,20, Math.abs(30-20));
		
		if(a.equals(b))
		{
			System.out.println("This Two one is same");
		}
	}

}
