
public class Rectangle {
		int x1,y1,x2,y2;
		public Rectangle()
		{
			
		}
		public Rectangle(int x1, int y1, int x2, int y2)
		{
			this.x1=x1;
			this.y1=y1;
			this.x2=x2;
			this.y2=y2;
		}
		public void set(int x1, int y1, int x2,int y2)
		{
			this.x1=x1;
			this.y1=y1;
			this.x2=x2;
			this.y2=y2;
		}
		public int square()
		{
			return Math.abs(((Math.abs(x1))-(Math.abs(x2))))*Math.abs(((Math.abs(y1))-(Math.abs(y2))));
		}
		
		public void show()
		{
			System.out.println("좌표 x1 : "+x1);
			System.out.println("좌표 y1 : "+y1);
			System.out.println("좌표 x2 : "+x2);
			System.out.println("좌표 y2 : "+y2);
			System.out.println("넓이 : " + this.square());
		}
		
		public boolean equals(Rectangle r){
			if(this.square() == r.square())
			{
				return true;
			}
			return false;
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Rectangle r = new Rectangle();
			Rectangle s = new Rectangle(-2,2,-1,4);
			
			r.show();
			s.show();
			System.out.println(s.square());
			r.set(-2, 2, -1, 4);
			r.show();
			System.out.println(r.square());
			if(r.equals(s))
			{
				System.out.println("It is same rectangle");
			}
	}

}
