import java.util.Scanner;

abstract class DObject1{
	public DObject1 next;
	public DObject1(){
		next=null;
	}
	abstract public void draw();
}
class Line extends DObject1{
	public void draw()
	{
		System.out.println("Line");
	}
}
class Rect extends DObject1{
	public void draw(){
		System.out.println("Rect");
	}
	
}

class Circle extends DObject1{

public void draw() {
System.out.println("Circle");

}

}
public class DObject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		
		int menu;
		int objectType;
		int delPlace;
		DObject1[] obj = new DObject1[10];
		int i = 0;
		
		while(true){
			
			System.out.print("삽입(1), 삭제(2), 모두 보기(3), 종료(4)>>");
			menu = in.nextInt();
		
			if(menu == 4)
				break;
			
				switch(menu)
				{
				case 1:
				System.out.print("도형 종류 Line(1), Rect(2), Circle(3)>>");
				objectType = in.nextInt();

				switch(objectType){
				case 1:
				obj[i] = new Line();
				i++;
				break;

				case 2:
				obj[i] = new Rect();
				i++;
				break;

				case 3:
				obj[i] = new Circle();
				i++;
				break;
				}
				break;

				case 2:
				System.out.print("삭제할 도형의 위치>>");
				delPlace = in.nextInt();
				if(delPlace > i){
				System.out.println("삭제할 수 없습니다.");
				break;
				}

				for(int j = (delPlace-1); j<i; j++){
				obj[j] = obj[j+1];
				}
				i--;

				break;

				case 3:
				for(int k=0; k<i; k++){
				obj[k].draw();
				}
				break;

				default:
				System.out.println("메뉴를 다시 입력해 주세요");
				}

		}	
	}
}
