import java.io.*;
import java.lang.*;
import java.util.Random.*;
import java.lang.Object;

public class Math 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		double d= 0;
		double res[]= new double[10];
		
		int i= 0;
		while(i<10)
		{
			d= Math.random()*50;
			if(d>10)
			{
				res[i]= d;
				i++;
			}
		}
		for(int k=0; k<10; k++)
		{
			System.out.print((k+1)+"번째 난수"+"\t");
			System.out.print(Math.round(res[k]));
			System.out.println();
	    }
  }
}

