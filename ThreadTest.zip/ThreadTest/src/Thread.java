
import java.lang.Thread;

public class Thread {
	String ThreadName;
	public Thread(String name)
	{
		ThreadName=name;
	}
	public void run()
	{
		for(int i=0; i<100; i++)
		{
			System.out.println("Hellow"+ThreadName+"haha");
			try
			{
				sleep(100);
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
		}
	}
}

class Thread{
public static void main(String args[])
{
	ShowThread st1=new ShowThread("good thread");
	ShowThread st2=new showThread("second thread");
	st1.start();
	st2.start();
}
}
