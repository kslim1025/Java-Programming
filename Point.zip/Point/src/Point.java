class MyPoint{
	int a,b;
	
	public MyPoint(int a, int b)
	{
		this.a= a;
		this.b= b;
	}
	public String toString(){
		return "MyPoint("+a+","+b+")";
	}
}
public class Point {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyPoint a= new MyPoint(3,20);
		System.out.println(a);
	}

}
