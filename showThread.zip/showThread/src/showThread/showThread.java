package showThread;

//java.lang.Object;

public class showThread extends Thread 
{
	String threadName;
	public showThread(String name)
	{
		threadName=name;
	}
public void run()
{
	for(int i=0; i<15; i++)
	{
		System.out.println("hello"+threadName+"입니다.");
		try
		{
			sleep(500);
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
	}
}
}

class ThreadUnderstand
{
	public static void main(String args[])
	{
		showThread st1=new showThread("멋진 쓰레드");
		showThread st2=new showThread("예쁜 쓰레드");
		st1.start();
		st2.start();
		st1.run();
		st2.run();
		st1.stop();
		st2.stop();
	}
}
