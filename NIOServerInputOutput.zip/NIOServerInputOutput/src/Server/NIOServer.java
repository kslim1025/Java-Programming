package Server;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.Charset;

public class NIOServer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ServerSocketChannel serverSocketChannel = null;
		try {
			serverSocketChannel = serverSocketChannel.open();
			serverSocketChannel.configureBlocking(true);
			serverSocketChannel.bind(new InetSocketAddress(5000));
			while (true) {
				System.out.println("[Connet wating...]");
				SocketChannel socketChannel = serverSocketChannel.accept();
				InetSocketAddress isa = (InetSocketAddress) socketChannel.getRemoteAddress();
				System.out.println("[Connet permission...]" + isa.getHostName());

				// 클라이언트로부터 데이터를 받음
				ByteBuffer byteBuffer = null;
				Charset charset = Charset.forName("UTF-8");
				int byteCount = socketChannel.read(byteBuffer);
				byteBuffer.flip();
				String message = charset.decode(byteBuffer).toString();
				System.out.println("[Successful Get data]" + message);

				// 클라이언트로 데이터를보냄
				byteBuffer = charset.encode("Hello client");
				socketChannel.write(byteBuffer);
				System.out.println("[Successful Send to message]");

			}
		} catch (Exception e) {

		}
		
		if (serverSocketChannel.isOpen()) {
			try {
				serverSocketChannel.close(); // 채널을 닫아야 포트 재사용 가능
			} catch (IOException e1) {
			}
		}
	}
}
