
public class FFArray {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		int Array[][]= new int[4][4];
		
		for(int i=0;i<Array.length;i++)//배열생성 
		{
			for(int j =0;j<Array.length;j++)
			{
				Array[i][j]=0;
			}
		}
		
		int n=0;
		while(n<8)//랜덤함수 생성 
		{
			int i= (int)(Math.random()*4); //배열이 4x4라서 곱하기 4를 해
			int j= (int)(Math.random()*4);
			
			if(Array[i][j]==0)
			{
				Array[i][j]=(int)Math.round(Math.random()*9+1);
				n++;
			}
		}
		for(int i=0;i<Array.length;i++)
		{
			for(int j=0;j<Array.length;j++)
				System.out.println(Array[i][j]+"\n");
		}
	}

}
