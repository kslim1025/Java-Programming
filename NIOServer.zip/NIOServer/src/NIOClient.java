import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.SocketChannel;

public class NIOClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SocketChannel socketChannel = null;
		try{
			socketChannel = SocketChannel.open();
			socketChannel.configureBlocking(true);
			System.out.println("Requirment for Connect");
			socketChannel.connect(new InetSocketAddress("localhost",5000));
			System.out.println("Successful Connect");
		}catch(Exception e){}
		if(socketChannel.isOpen()){
			try{
				socketChannel.close();
			}catch(IOException e1){}
		}
	}

}
