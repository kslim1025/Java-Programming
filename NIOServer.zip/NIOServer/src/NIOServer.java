import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;

public class NIOServer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ServerSocketChannel serverSocketChannel = null; //ServerSocketChannel을생성한다.
		try{
			serverSocketChannel=serverSocketChannel.open();
			serverSocketChannel.configureBlocking(true);
			serverSocketChannel.bind(new InetSocketAddress(5001));
			
			while(true)
			{
				System.out.println("[Connection wating...]");
				SocketChannel socketChannel = serverSocketChannel.accept();
				InetSocketAddress isa= (InetSocketAddress) socketChannel.getRemoteAddress();
				System.out.println("[Connection permission!]"+ isa.getHostName());
			}
		   }catch(Exception e){
			   
		   }
		if(serverSocketChannel.isOpen())
			try{
				serverSocketChannel.close();
				//System.out.println("[Connection Close]");
				}
			catch(IOException e1)
				{}	
	 
	}
}
