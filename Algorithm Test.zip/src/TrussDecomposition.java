import java.util.*;

public class TrussDecomposition {

    int n, m;
    int[] degree;
    PriorityQueue<List<Integer>> support;
    List<Set<Integer>> graph;
    List<Map<Integer, Integer>> trussness;

    TrussDecomposition(){
        graph = new ArrayList<>();
        support = new PriorityQueue<>(new ListComparator());
        trussness = new ArrayList<>();
    }

    int max(int a, int b){
        return a > b ? a : b;
    }

    //初始化，读入二维数组表示的无向图边集 int[][2]
    public boolean init(int[][] a){//original graph should be stored in a int[][2]
        n = 0; m = a.length;
        for (int i = 0; i < m; i ++) {
            if (a[i].length < 2) {
                System.out.println("Invalid edge! " + i + " : " + a[i].length);
                return false;
            }
            if (a[i][0] < 0 || a[i][1] < 0) {
                System.out.println("Invalid edge! " + i + " : " + a[i][0] + ", " + a[i][1]);
                return false;
            }
            n = max(n, max(a[i][0], a[i][1]));
        }
        n += 1;
        degree = new int[n];
        graph.clear();
        for (int i = 0; i < n; i ++) {
            graph.add(new HashSet<>());
            degree[i] = 0;
        }
        for (int i = 0; i < m; i ++){
            graph.get(a[i][0]).add(a[i][1]);
            graph.get(a[i][1]).add(a[i][0]);
            degree[a[i][0]] ++;
            degree[a[i][1]] ++;
        }
        return true;
    }

    //初始化2，读入List<Set>表示的无向图边集
    public boolean init(List<Set<Integer>> g){//original graph can be stored in a List<Set<Int>> manner
        graph.clear();
        for (Set<Integer> s: g) {
            Set<Integer> s1 = new HashSet<>();
            s1.addAll(s);
            graph.add(s1);
        }
        n = graph.size();
        degree = new int[n];
        for (int i = 0; i < n; i ++)
            degree[i] = 0;
        for (int i = 0; i < n; i ++){
            for (Integer v: graph.get(i)){
                if (v < 0 || v >= n) {
                    System.out.println("Invalid edge! " + i + ", " + v);
                    return false;
                }
                degree[v] ++;
                degree[i] ++;
            }
        }
        return true;
    }

    //计算每条边的support(即属于多少个三角形)
    private void get_support(){
        support.clear();
        for (int i = 0; i < n; i ++)
            for (Integer v: graph.get(i)){ //enumerate edge (i, v)
                // enumerate i's neighbours, otherwise things will be done when i' = v
                if (degree[i] < degree[v] || (degree[i] == degree[v] && i < v)){
                    int sup = 0;
                    Set<Integer> s = graph.get(v);
                    for (Integer w: graph.get(i))
                        if (s.contains(w)){ // triangle (i, v, w)
                            sup ++;
                        }
                    support.add(makeEdge(i, v, sup)); // sup: (i ~ v)
                }
            }
    }

    private List<Integer> makeEdge(int u, int v, int sup){
        List<Integer> e = new ArrayList<>();
        e.add(sup);
        if (u < v){
            e.add(u); e.add(v);
        } else {
            e.add(v); e.add(u);
        }
        return e;
    }

    private List<Integer> makeEdge2(int u, int v){
        List<Integer> e = new ArrayList<>();
        if (u < v){
            e.add(u); e.add(v);
        } else {
            e.add(v); e.add(u);
        }
        return e;
    }

    //主函数，计算所有边的trussness
    public void work(){
        get_support();//stored in a min heap
        trussness.clear();
        for (int i = 0; i < n; i ++)
            trussness.add(new HashMap<>());
        //use a map to check the newest support of every edge
        Map<List<Integer>, Integer> edges = new HashMap<>();
        for (List<Integer> a: support){
            edges.put(makeEdge2(a.get(1), a.get(2)), a.get(0));
        }
        int k = 2;
        while (!support.isEmpty()){
            while (!support.isEmpty() && support.peek().get(0) <= k - 2){
                List<Integer> e = support.poll();
                int u = e.get(1), v = e.get(2);
                if (!graph.get(u).contains(v)) // e has been deleted since (u ~ v) has been calculated
                    continue;
                trussness.get(u).put(v, k);
                trussness.get(v).put(u, k);
                graph.get(u).remove(v);
                graph.get(v).remove(u);
                degree[u] --; degree[v] --;
                if (degree[u] > degree[v]){ // make sure that degree[u] <= degree[v]
                    int t = u; u = v; v = t;
                }
                Set<Integer> s = graph.get(v);
                for (int w: graph.get(u))
                    if (s.contains(w)){ // triangle (u, v, w)
                        List<Integer> e1 = makeEdge2(u, w);
                        if (graph.get(u).contains(w)) {
                            int k1 = edges.get(e1) - 1;
                            edges.put(e1, k1);
                            support.add(makeEdge(u, w, k1));
                        }
                        List<Integer> e2 = makeEdge2(v, w);
                        if (graph.get(v).contains(w)) {
                            int k2 = edges.get(e2) - 1;
                            edges.put(e2, k2);
                            support.add(makeEdge(v, w, k2));
                        }
                    }
            }
            k ++;
        }
    }

    public List<Map<Integer, Integer>> getTrussness() {
        return trussness;
    }
}
