import java.awt.*;
import java.io.*;
import java.sql.Time;
import java.util.*;
import java.util.List;

public class Run {

    static void writeTxt(String filename, List<List<List<Integer>>> result){
        try {
            File f = new File(filename);
            Writer output = new FileWriter(f);
            int n = result.size();
            int m = 0;
            for (int i = 0; i < n; i ++)
                if (result.get(i).size() > 0)
                    m ++;
            output.write(n + "\n");
            output.flush();
            for (int i = 0; i < n; i ++){
                int ni = result.get(i).size();
                if (ni == 0)
                    continue;
                output.write(ni + "");
                for (List<Integer> e: result.get(i))
                    output.write(" " + e.get(0) + " " + e.get(1));
                output.write("\n");
            }
            output.close();
        } catch (Exception e){
            System.out.println("Error when creating file!");
            e.printStackTrace();
        }
    }

    public static void main(String args[]){

        //int[][] b = {{1, 2}, {1, 3}, {2, 4}, {3, 4}, {2, 5}, {4, 5}, {1, 4}};
        /*int[][] b = {{1, 2}, {1, 3}, {1, 4}, {1, 5}, {2, 3}, {2, 4}, {3, 4}, {3, 7}, {3, 9},
                {4, 5}, {4, 6}, {4, 7}, {5, 6}, {5, 7}, {6, 7}, {6, 8}, {6, 11}, {7, 8}, {7, 9},
                {7, 10}, {7, 11}, {8, 9}, {8, 10}, {8, 11}, {9, 10}, {9, 11}, {10, 11}};*/

        if (args.length < 3){
            System.out.println("Error! Require more arguments. usage: <file> <n> <m>");
            return;
        }
        ReadData rd = new ReadData();
        TrussDecomposition td = new TrussDecomposition();
        IndexConstruction ic = new IndexConstruction();
        CommunitySearch cs = new CommunitySearch();
        try {
            rd.setVertex(Integer.valueOf(args[1]));
            rd.setEdge(Integer.valueOf(args[2]));
            if (!td.init(rd.getGraph(args[0])))
                return;
        } catch (Exception e){
            System.out.println("Error in reading data!");
            e.printStackTrace();
            return;
        }

        System.out.println("Start running...");
        try {
            long t0 = System.currentTimeMillis();
            td.work();
            long t1 = System.currentTimeMillis();
            System.out.println("Truss decomposition completed. It takes " + (t1 - t0) + " ms.");
            if (!ic.init(td.getTrussness()))
                return;
            ic.work();
            long t2 = System.currentTimeMillis();
            System.out.println("Index construction completed. It takes " + (t2 - t1) + " ms.");
            if (!cs.init(ic.getEquiTruss(), ic.getContent(), ic.getH(), ic.getK_ness()))
                return;
            System.out.println("Now you can start giving queries.");
            System.out.println("Type 1 -- [Q]uery <q> <k>");
            System.out.println("Type 2 -- [I]nsert <u> <v>");
            System.out.println("Type 3 -- [D]elete <u> <v>");
            System.out.println("Type 4 -- [S]ave <filename>");
        } catch (Exception e){
            e.printStackTrace();
        }

        DynamicUpdate du = new DynamicUpdate(cs);
        Scanner sc = new Scanner(System.in);
        while (true){
            try {
                String operation = sc.next();
                char ch = operation.charAt(0);
                if (ch == 'Q' || ch == 'q'){
                    int q = sc.nextInt(), k = sc.nextInt();
                    System.out.println("--------------------------------------------------------");
                    System.out.println("pending...");
                    long t0 = System.currentTimeMillis();
                    du.executeUpdate();
                    if (!cs.work(q, k)){
                        System.out.println("Invalid query!");
                        continue;
                    }
                    for (int i = 0; i < cs.getCommunities().size(); i ++)
                        System.out.println(cs.getCommunities().get(i));
                    System.out.println("finished in " + (System.currentTimeMillis() - t0) + "ms");
                    System.out.println("--------------------------------------------------------");
                } else if (ch == 'I' || ch == 'i') {
                    int u = sc.nextInt(), v = sc.nextInt();
                    if (!du.add_insert_edge(u, v))
                        System.out.println("Invalid query!");
                } else if (ch == 'D' || ch == 'd') {
                    int u = sc.nextInt(), v = sc.nextInt();
                    if (!du.add_delete_edge(u, v))
                        System.out.println("Invalid query!");
                } else if (ch == 'S' || ch == 's') {
                    String file = sc.next();
                    writeTxt(file, cs.getCommunities());
                } else if (ch == 'P' || ch == 'p') {
                    du.executeUpdate();
                    int cn = 0;
                    for (List<List<Integer>> l: cs.getEdges())
                        if (l.size() > 0)
                            cn ++;
                    System.out.println("k-truss-number: " + cn);
                    int sz = 0;
                    for (int i = 0; i < cs.getEdges().size() && sz < 10; i ++){
                        if (cs.getEdges().get(i).size() == 0)
                            continue;
                        System.out.println("k = " + cs.getKn().get(i) + ", e = " + cs.getGraph().get(i)
                                + ", edges = " + cs.getEdges().get(i));
                        sz ++;
                    }
                } else if (ch == 'E' || ch == 'e'){
                    System.out.println("Goodbye~");
                    break;
                } else {
                    System.out.println("Invalid query!");
                }
            } catch (Exception e){
                System.out.println("Oops... An error eccured!");
                e.printStackTrace();
                break;
            }
        }
    }
}