import java.util.Comparator;
import java.util.List;

public class ListComparator implements Comparator<List<Integer>> {
    public int compare(List<Integer> a, List<Integer> b){
        int n = a.size(), m = b.size();
        for (int i = 0; i < n && i < m; i ++)
            if (a.get(i) < b.get(i))
                return -1;
            else if (a.get(i) > b.get(i))
                return 1;
        if (n < m)
            return -1;
        if (n > m)
            return 1;
        return 0;
    }
}
