import java.util.*;

public class DynamicUpdate {

    //input
    List<Set<Integer>> graph;// super-graph G(V, E)
    List<List<List<Integer>>> edges; // edges[i] = G[i].edge_list
    List<Set<Integer>> H; // H[i] = {vi belongs to V}
    Map<Integer, Integer> kn;
    Map<Integer, Set<Integer>> raw_graph; // original edges
    Map<Integer, Map<Integer, Integer>> edge_vid; // which super-node every original edge belongs to
    Map<Integer, Integer> degree;
    //bulk update
    List<List<Integer>> delete_edges;
    List<List<Integer>> insert_edges;
    //affected data
    Set<Integer> vid;  //affected super-nodes
    Map<Integer, Integer> alias;  //affected graph's verex set V' -> {0, 1, 2, ..., n'}
    List<Integer> real_id; // {0, 1, 2, ..., n'} -> V'
    List<Integer> remove_super_id;

    DynamicUpdate(CommunitySearch cs){
        graph = cs.getGraph();
        edges = cs.getEdges();
        H = cs.getH();
        kn = cs.getKn();
        delete_edges = new ArrayList<>();
        insert_edges = new ArrayList<>();
        //for temporary use
        remove_super_id = new ArrayList<>();
        vid = new HashSet<>();
        alias = new HashMap<>();
        real_id = new ArrayList<>();
        //storing the original graph
        raw_graph = new HashMap<>();
        degree = new HashMap<>();
        edge_vid = new HashMap<>();
        for (int i = 0; i < edges.size(); i ++) {
            for (List<Integer> e : edges.get(i)) {
                int u = e.get(0), v = e.get(1); // u < v
                //raw_graph
                if (!raw_graph.containsKey(u))
                    raw_graph.put(u, new HashSet<>());
                if (!raw_graph.containsKey(v))
                    raw_graph.put(v, new HashSet<>());
                raw_graph.get(u).add(v);
                raw_graph.get(v).add(u);
                //degree
                if (!degree.containsKey(u))
                    degree.put(u, 0);
                if (!degree.containsKey(v))
                    degree.put(v, 0);
                degree.put(u, degree.get(u) + 1);
                degree.put(v, degree.get(v) + 1);
                //edge_vid
                if (!edge_vid.containsKey(u))
                    edge_vid.put(u, new HashMap<>());
                edge_vid.get(u).put(v, i);
            }
        }
    }

    List<Integer> makeEdge2(int u, int v){
        List<Integer> e = new ArrayList<>();
        if (u < v){
            e.add(u); e.add(v);
        } else {
            e.add(v); e.add(u);
        }
        return e;
    }

    public boolean add_delete_edge(int u, int v){
        if (u == v || !raw_graph.containsKey(u) || !raw_graph.get(u).contains(v)) {
            System.out.println("Cannot delete edge " + u + " to  "+ v);
            return false;
        }
        if (insert_edges.size() > 0)
            executeUpdate();
        raw_graph.get(u).remove(v);
        raw_graph.get(v).remove(u);
        degree.put(u, degree.get(u) - 1);
        degree.put(v, degree.get(v) - 1);
        delete_edges.add(makeEdge2(u, v));
        return true;
    }

    public boolean add_insert_edge(int u, int v){
        if (u == v || u >= H.size() || v >= H.size() || (raw_graph.containsKey(u) && raw_graph.get(u).contains(v))) {
            System.out.println("Cannot add edge " + u + " to  "+ v);
            return false;
        }
        if (delete_edges.size() > 0)
            executeUpdate();
        if (!raw_graph.containsKey(u))
            raw_graph.put(u, new HashSet<>());
        if (!raw_graph.containsKey(v))
            raw_graph.put(v, new HashSet<>());
        raw_graph.get(u).add(v);
        raw_graph.get(v).add(u);
        if (!degree.containsKey(u))
            degree.put(u, 0);
        if (!degree.containsKey(v))
            degree.put(v, 0);
        degree.put(u, degree.get(u) + 1);
        degree.put(v, degree.get(v) + 1);
        insert_edges.add(makeEdge2(u, v));
        return true;
    }

    void deal_insert(){
        for (List<Integer> edge: insert_edges){
            int u = edge.get(0), v = edge.get(1);
            if (!raw_graph.get(u).contains(v))
                continue;
            vid.addAll(H.get(u));
            vid.addAll(H.get(v));
            if (!edge_vid.containsKey(u))
                edge_vid.put(u, new HashMap<>());
            edge_vid.get(u).put(v, -1);
        }
        //insert_edges.clear(); cannot do it here
    }

    void deal_delete(){
        Set<Integer> vi = new HashSet<>();  //存储删掉的这些边分别所在的super-node集合
        for (List<Integer> edge: delete_edges){
            int u = edge.get(0), v = edge.get(1);
            vi.add(edge_vid.get(u).get(v));
            edge_vid.get(u).remove(v); // 删了
        }
        for (int v: vi){
            vid.add(v);
            for (int u: graph.get(v))// 枚举所有相邻 super-node，找出所有 trussness 值更小的
                if (kn.get(u) < kn.get(v))
                    vid.add(u);
        }
        delete_edges.clear();
    }

    public void executeUpdate(){
        //no recent changes
        if (delete_edges.size() == 0 && insert_edges.size() == 0)
            return;
        vid.clear();
        deal_insert();
        deal_delete();
        //对涉及子图的点集重标号
        int n = 0;
        alias.clear();
        real_id.clear();
        for (int vi: vid)
            for (List<Integer> e: edges.get(vi))
                if (edge_vid.get(e.get(0)).containsKey(e.get(1)))
                    insert_edges.add(makeEdge2(e.get(0), e.get(1)));
        //System.out.println("insert_edges: " + insert_edges);
        //取出涉及子图的边集，删去相应的 super-node
        List<List<Integer>> remove_edges = new ArrayList<>();
        for (List<Integer> e: insert_edges){
            int u = e.get(0), v = e.get(1); // u < v
            if (!alias.containsKey(u)) {
                alias.put(u, n); n ++;
                real_id.add(u);
            }
            if (!alias.containsKey(v)) {
                alias.put(v, n); n ++;
                real_id.add(v);
            }
            remove_edges.add(makeEdge2(u, v));
            edge_vid.get(u).put(v, -1);
        }
        for (int u: real_id)
            for (int v: raw_graph.get(u))
                if (v > u && real_id.contains(v)){
                    if (edge_vid.get(u).get(v) != -1){
                        remove_edges.add(makeEdge2(u, v));
                    }
                }
        int[][] re = new int[remove_edges.size()][2];
        int m = 0;
        for (List<Integer> e: remove_edges){
            re[m][0] = alias.get(e.get(0));
            re[m][1] = alias.get(e.get(1));
            m ++;
        }
        for (int vi: vid){
            removeSuperNode(vi);
        }
        insert_edges.clear();
        //计算 remove_edges 的 EquiTruss
        TrussDecomposition td = new TrussDecomposition();
        td.init(re);
        td.work();
        IndexConstruction ic = new IndexConstruction();
        ic.init(td.getTrussness());
        ic.work();
        //ic 的super-node与node编号都是从 0 开始，需要映射回去
        List<List<List<Integer>>> vs = ic.getContent();
        int[] nvid = new int[vs.size()];
        for (int i = 0; i < vs.size(); i ++){
            //首先赋予新编号
            if (remove_super_id.size() > 0){
                nvid[i] = remove_super_id.get(0);
                remove_super_id.remove(0);
            } else {
                nvid[i] = graph.size();
                graph.add(new HashSet<>());
                edges.add(new ArrayList<>());
            }
            //更新super-node的信息
            kn.put(nvid[i], ic.getK_ness().get(i));
            //修改原图中的edge_vid
            for (List<Integer> e: vs.get(i)){
                int u = real_id.get(e.get(0)), v = real_id.get(e.get(1));
                if (u > v){
                    int t = u; u = v; v = t;
                }
                if (edge_vid.get(u).get(v) != -1){ //boundary edge
                    continue;
                }
                H.get(u).add(nvid[i]);
                H.get(v).add(nvid[i]);
                edge_vid.get(u).put(v, nvid[i]);
                edges.get(nvid[i]).add(makeEdge2(u, v));
            }
        }
        //更新super-graph的边集
        List<Set<Integer>> g1 = ic.getEquiTruss();
        for (int i = 0; i < g1.size(); i ++){
            for (int j: g1.get(i)){
                graph.get(nvid[i]).add(nvid[j]);
            }
            int ki = kn.get(nvid[i]);
            Set<Integer> merge_list = new HashSet<>();
            for (int j = 0; j < vs.get(i).size(); j ++) {
                int u = real_id.get(vs.get(i).get(j).get(0)), v = real_id.get(vs.get(i).get(j).get(1));
                if (u > v){
                    int t = u; u = v; v = t;
                }
                int v1 = edge_vid.get(u).get(v);
                if (v1 != nvid[i]) { //boundary edge
                    if (kn.get(v1) == ki)
                        merge_list.add(v1);
                    continue;
                }
                if (degree.get(u) > degree.get(v)){
                    int t = u; u = v; v = t;
                }
                for (int w: raw_graph.get(u))
                    if (raw_graph.get(v).contains(w)){
                        List<Integer> ea = makeEdge2(u, w);
                        int va = edge_vid.get(ea.get(0)).get(ea.get(1));
                        int ka = kn.get(va);
                        List<Integer> eb = makeEdge2(v, w);
                        int vb = edge_vid.get(eb.get(0)).get(eb.get(1));
                        int kb = kn.get(vb);
                        int k2 = Min(ka, kb);
                        if (va != nvid[i]) {
                            if (k2 >= ki && ka == ki)
                                merge_list.add(va);
                            else {
                                graph.get(nvid[i]).add(va);
                                graph.get(va).add(nvid[i]);
                            }
                        }
                        if (vb != nvid[i]) {
                            if (k2 >= ki && kb == ki)
                                merge_list.add(vb);
                            else {
                                graph.get(nvid[i]).add(vb);
                                graph.get(vb).add(nvid[i]);
                            }
                        }
                    }
            }
            for (int v: merge_list){
                for (int u: graph.get(v)){
                    graph.get(u).add(nvid[i]);
                    graph.get(nvid[i]).add(u);
                }
                for (List<Integer> e: edges.get(v)) {
                    edges.get(nvid[i]).add(makeEdge2(e.get(0), e.get(1)));
                    H.get(e.get(0)).add(nvid[i]);
                    H.get(e.get(1)).add(nvid[i]);
                    edge_vid.get(e.get(0)).put(e.get(1), nvid[i]);
                }
                removeSuperNode(v);
            }
            if (edges.get(nvid[i]).size() == 0)
                removeSuperNode(nvid[i]);
        }
    }

    void removeSuperNode(int vi){
        for (List<Integer> e: edges.get(vi)) {
            int u = e.get(0), v = e.get(1); // u < v
            H.get(u).remove(vi);
            H.get(v).remove(vi);
        }
        for (int u: graph.get(vi)) {
            graph.get(u).remove(vi);
        }
        graph.get(vi).clear();
        edges.get(vi).clear();
        kn.put(vi, 0);
        remove_super_id.add(vi); // 多了一个无用的 super-id 编号，留着以后用
    }

    int Min(int x, int y){
        return x < y ? x : y;
    }

}
