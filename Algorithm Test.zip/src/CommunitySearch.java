import java.util.*;

public class CommunitySearch {

    int n;
    //input
    List<Set<Integer>> graph;// G(V, E)
    List<List<List<Integer>>> edges; // edges[i] = G[i].edge_list
    List<Set<Integer>> H; // H[i] = {vi belongs to V}
    Map<Integer, Integer> kn;
    //temporary
    Map<Integer, Boolean> processed;
    //output
    List<List<List<Integer>>> communities;

    CommunitySearch(){
        n = 0;
        graph = new ArrayList<>();
        edges = new ArrayList<>();
        H = new ArrayList<>();
        processed = new HashMap<>();
        communities = new ArrayList<>();
        kn = new HashMap<>();
    }

    public boolean init(List<Set<Integer>> equiTruss, List<List<List<Integer>>> content, List<Set<Integer>> h, Map<Integer, Integer> k_ness){
        n = equiTruss.size();
        if (content.size() != n || k_ness.size() != n) {
            n = 0;
            System.out.println("Incompatible size of Super-Graph! " + n + ", " + content.size() + ", " + k_ness.size());
            return false;
        }
        graph.clear();
        for (int i = 0; i < n; i ++) {
            Set<Integer> s1 = new HashSet<>();
            s1.addAll(equiTruss.get(i));
            graph.add(s1);
            for (int v: s1)
                if (v < 0 || v >= n){
                    n = 0;
                    System.out.println("Invalid super-edge! " + i + ", " + v);
                    return false;
                }
        }
        edges.clear();
        int vs = h.size();
        for (int i = 0; i < n; i ++) {
            List<List<Integer>> vi = new ArrayList<>();
            for (List<Integer> e: content.get(i)){
                int u = e.get(0), v = e.get(1);
                if (u < 0 || u >= vs || v < 0 || v >= vs){
                    n = 0;
                    System.out.println("Invalid vertex id! " + u + ", " + v);
                    return false;
                }
                vi.add(makeEdge2(u, v));
            }
            edges.add(vi);
        }
        H.clear();
        for (int i = 0; i < vs; i ++){
            Set<Integer> s1 = new HashSet<>();
            s1.addAll(h.get(i));
            H.add(s1);
            for (int v: s1)
                if (v < 0 || v >= n){
                    n = 0;
                    System.out.println("Invalid super-node id! " + i + ", " + v);
                    return false;
                }
        }
        kn.clear();
        kn.putAll(k_ness);
        for (int k: k_ness.values())
            if (k < 0 || k > vs - 2){
                n = 0;
                System.out.println("Invalid k value of edge! " + k + " (limit = " + (vs - 2) + ")");
                return false;
            }
        return true;
    }

    public boolean work(int q, int K){
        communities.clear();
        processed.clear();
        if (q < 0 || q > H.size())
            return false;
        n = H.size();
        for (int i = 0; i < n; i ++)
            processed.put(i, false);
        for (int v: H.get(q))
            if (kn.get(v) >= K && !processed.get(v)){
                processed.put(v, true);
                List<List<Integer>> ci = new ArrayList<>();
                Queue<Integer> que = new LinkedList<>();
                que.add(v);
                while (!que.isEmpty()){
                    int u = que.poll();
                    for (List<Integer> e: edges.get(u))
                        ci.add(makeEdge2(e.get(0), e.get(1)));
                    for (int w: graph.get(u))
                        if (kn.get(w) >= K && !processed.get(w)){
                            processed.put(w, true);
                            que.add(w);
                        }
                }
                communities.add(ci);
            }
        return true;
    }

    List<Integer> makeEdge2(int u, int v){
        List<Integer> e = new ArrayList<>();
        e.add(u); e.add(v);
        return e;
    }

    public List<List<List<Integer>>> getCommunities() {
        return communities;
    }

    public List<Set<Integer>> getGraph() {
        return graph;
    }

    public List<List<List<Integer>>> getEdges() {
        return edges;
    }

    public List<Set<Integer>> getH() {
        return H;
    }

    public Map<Integer, Integer> getKn() {
        return kn;
    }
}
