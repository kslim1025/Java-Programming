import java.util.*;

public class IndexConstruction {

    int n, sn;
    int[] degree;
    List<Map<Integer, Integer>> trussness;
    //temporary
    List<Map<Integer, Boolean>> processed; // processed(u, v) = T|F
    List<Map<Integer, Set<Integer>>> list; // list(u, v) = {id}
    Map<Integer, List<List<Integer>>> k_edges; // k_e[i] = {edges that t(e) = k}
    //results
    List<Set<Integer>> equiTruss;// G(V, E)
    List<List<List<Integer>>> content; // content[i] = G[i].edge_list
    List<Set<Integer>> H; // H[i] = {vi belongs to V}
    Map<Integer, Integer> k_ness;

    IndexConstruction(){
        n = 0;
        sn = 0;
        trussness = new ArrayList<>();
        processed = new ArrayList<>();
        list = new ArrayList<>();
        k_edges = new HashMap<>();
        content = new ArrayList<>();
        H = new ArrayList<>();
        equiTruss = new ArrayList<>();
        k_ness = new HashMap<>();
    }

    public boolean init(List<Map<Integer, Integer>> truss) { //truss[i][j]: trussness of e(i, j)
        n = truss.size();
        trussness.clear();
        for (int i = 0; i < n; i ++) {
            Map<Integer, Integer> s1 = new HashMap<>();
            s1.putAll(truss.get(i));
            trussness.add(s1);
            for (int v: s1.keySet())
                if (v < 0 || v >= n){
                    n = 0;
                    System.out.println("Invalid edge! " + i + ", " + v);
                    return false;
                }
        }
        return true;
    }

    //预处理所有点的度数和其它信息
    void prepare(){ //calculate int[] degree, List<Edge> k_edges
        degree = new int[n];
        k_edges.clear();
        processed.clear();
        list.clear();
        for (int i = 0; i < n; i ++) {
            processed.add(new HashMap<>());
            list.add(new HashMap<>());
        }
        for (int i = 0; i < n; i ++)
            for (Map.Entry<Integer, Integer> e: trussness.get(i).entrySet())
                if (e.getKey() > i){ //enumerate each edge only once
                    int v = e.getKey(), k = e.getValue();
                    degree[i] ++;
                    degree[v] ++;
                    if (!k_edges.containsKey(k))
                        k_edges.put(k, new ArrayList<>());
                    k_edges.get(k).add(makeEdge2(i, v));
                    processed.get(i).put(v, false);
                    list.get(i).put(v, new HashSet<>());
                }
    }

    //主函数，计算EquiTruss数据结构，即所有k-truss-community
    //保留在 equiTruss, content, H, k_ness 四个数据结构中
    public void work(){
        prepare();
        sn = 0;
        equiTruss.clear();
        content.clear();
        H.clear();
        k_ness.clear();
        for (int i = 0; i < n; i ++)
            H.add(new HashSet<>());
        //从小到大枚举k
        for (int k: k_edges.keySet()) {
            List<List<Integer>> ke = k_edges.get(k);
            for (List<Integer> edge: ke){
                if (processed.get(edge.get(0)).get(edge.get(1)))
                    continue;
                processed.get(edge.get(0)).put(edge.get(1), true);
                sn ++;
                int vid = sn - 1;
                equiTruss.add(new HashSet<>());
                k_ness.put(vid, k);
                List<List<Integer>> vi = new ArrayList<>();
                content.add(vi);
                Queue<List<Integer>> que = new LinkedList<>();
                que.add(edge);
                //从edge开始BFS
                while (!que.isEmpty()){
                    List<Integer> e = que.poll();
                    int u = e.get(0), v = e.get(1);
                    vi.add(e); // add to super-node
                    H.get(u).add(vid);
                    H.get(v).add(vid);
                    for (int id: list.get(u).get(v)){ // add super-edge
                        equiTruss.get(vid).add(id);
                        equiTruss.get(id).add(vid);
                    }
                    // connections
                    if (degree[u] > degree[v]){ // assume that degree[u] <= degree[v]
                        int t = u; u = v; v = t;
                    }
                    Map<Integer, Integer> gu = trussness.get(u);
                    Map<Integer, Integer> gv = trussness.get(v);
                    for (Map.Entry<Integer, Integer> eu: gu.entrySet()) {
                        int w = eu.getKey();
                        if (eu.getValue() >= k && gv.containsKey(w) && gv.get(w) >= k) {
                            ProcessEdge(u, w, que, k);
                            ProcessEdge(v, w, que, k);
                        }
                    }
                }
            }
        }
    }

    //扩展一条边(u, v)
    void ProcessEdge(int u, int v, Queue<List<Integer>> que, int k){
        if (u > v){
            int t = u; u = v; v = t;
        }
        if (trussness.get(u).get(v) == k){
            if (!processed.get(u).get(v)){
                processed.get(u).put(v, true);
                que.add(makeEdge2(u, v));
            }
        } else {
            if (!list.get(u).get(v).contains(sn - 1))
                list.get(u).get(v).add(sn - 1);
        }
    }

    List<Integer> makeEdge2(int u, int v){
        List<Integer> e = new ArrayList<>();
        e.add(u); e.add(v);
        return e;
    }

    public List<Map<Integer, Integer>> getTrussness() {
        return trussness;
    }

    public List<Set<Integer>> getEquiTruss() {
        return equiTruss;
    }

    public List<Set<Integer>> getH() {
        return H;
    }

    public List<List<List<Integer>>> getContent() {
        return content;
    }

    public Map<Integer, Integer> getK_ness() {
        return k_ness;
    }
}
