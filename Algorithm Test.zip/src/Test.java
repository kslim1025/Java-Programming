import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.*;
import java.util.Map.Entry;

public class Test {

    void testSort(){

        List<List<Integer>> a = new ArrayList<>();
        List<Integer> la = new ArrayList<>();
        la.add(1); la.add(2); la.add(3);
        List<Integer> lb = new ArrayList<>();
        lb.add(4); lb.add(1); lb.add(1);
        List<Integer> lc = new ArrayList<>();
        lc.add(-14); lc.add(1); lb.add(16);
        a.add(la); a.add(lb); a.add(lc);
        Collections.sort(a, new ListComparator());
        System.out.println(a);
    }
    
    
    public String getKAnalysis (List<Map<Integer, Integer>> truss) {
    	int kMax = 0, sum = 0, num = 0;
    	
    	for (Map<Integer, Integer> map : truss) 
    		for (Entry<Integer, Integer> entry : map.entrySet()) {
    			if (entry.getValue() > kMax) {
					kMax = entry.getValue();
				}
    			sum += entry.getValue();
    			num++;
    		}
		
    	return kMax + "," + sum/num;
    }
    
    
    public String getMaxCommunity(List<List<List<Integer>>> content, String file) {
    	List<Set<Integer>> maxVer = new ArrayList<Set<Integer>>();
    	List<List<List<Integer>>> maxEdge = new ArrayList<List<List<Integer>>>();
    	
    	int min;
    	int maxEdgeNum = 0, maxVerNum = 0;
		
    	for (List<List<Integer>> community : content) {
			if (maxEdge.size() < 10) {
				maxEdge.add(community);
			}
			else {
				min = 0;
				for (int i = 1; i < maxEdge.size(); i++) {
					if (maxEdge.get(i).size() <= maxEdge.get(min).size()) {
						min = i;
					}
				}
				
				if (community.size() > maxEdge.get(min).size()) {
					maxEdge.remove(min);
					maxEdge.add(community);
				}
				
			}
			
			
			if (maxVer.size() < 10) {
				Set<Integer> verSet = new HashSet<Integer>();
				for (List<Integer> edge : community) {
					verSet.add(edge.get(0));
					verSet.add(edge.get(1));
				}
				
				maxVer.add(verSet);
			}
			else {
				Set<Integer> verSet = new HashSet<Integer>();
				for (List<Integer> edge : community) {
					verSet.add(edge.get(0));
					verSet.add(edge.get(1));
				}
				
				min = 0;
				for (int i = 1; i < maxVer.size(); i++) {
					if (maxVer.get(i).size() <= maxVer.get(min).size()) {
						min = i;
					}
				}
				
				if (verSet.size() > maxVer.get(min).size()) {
					maxVer.remove(min);
					maxVer.add(verSet);
				}
				
			}
			
		}
    	
    	
    	try {
    		
			BufferedWriter writerEdge = new BufferedWriter(new FileWriter("./" + file
					+ "maxEdgeTop10.txt"));
			String line = "";
			for (int i = 0; i < maxEdge.size(); i++) {
				line = "";
				for (List<Integer> edges : maxEdge.get(i)) {
					line = line  + "(" + edges.get(0) + "," +edges.get(1) + ") ";
				}
				line = line.trim() + "\n";
				writerEdge.write(line);
				
				if (maxEdge.get(i).size() > maxEdgeNum) {
					maxEdgeNum = maxEdge.get(i).size();
				}
			}
			writerEdge.close();
			
			BufferedWriter writerVer = new BufferedWriter(new FileWriter("./" + file
					+ "maxVerTexTop10.txt"));
			for (int i = 0; i < maxVer.size(); i++) {
				line = "";
				for (Integer integer : maxVer.get(i)) {
					line = line + integer + " ";
				}
				line = line.trim() + "\n";
				writerVer.write(line);
				
				if (maxVer.get(i).size() > maxVerNum) {
					maxVerNum = maxVer.get(i).size();
				}
			}
			writerVer.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
    	
    	return maxEdgeNum + "," + maxVerNum;
	}
    

    public static void main(String args[]){
    	String[] files = {"amazon", "dblp", "youtube", "lj", "orkut"};
    	String[] filePrint = {"amazon", "dblp\t", "youtube", "lj\t", "orkut\t"};
    	int vertex[] = {334863, 317080, 1134890, 3997962, 3072441};
    	int edge[] = {925872, 1049866, 2987624, 1000000, 1000000};
    	int edges[] = {925872, 1049866, 2987624, 34681189, 117185083};
    	
    	//System.out.println("| Network \t|| |V|\t\t|| |E|\t\t|| dMax\t\t|| kMax\t|| kAverage\t|| "
        //		+ "Community size\t|| max edge num\t|| max node num\t|| td time\t|| ic time\t|");
        
    	int s = 5;
    	while (s < 5) {
    		ReadData readData = new ReadData();
    		readData.setVertex(vertex[s]);
    		readData.setEdge(edge[s]);
        	String file = "./data/" + files[s] + ".ungraph.txt";
    		int[][] graph = readData.getGraph(file);
    		int maxDegree = readData.getMaxDegree(graph);
        	
    		Date start = new Date();
    		
            TrussDecomposition td = new TrussDecomposition();
            td.init(graph);
            td.work();
            //System.out.println("td finished.");
            
            Date mid = new Date();
            
            IndexConstruction ic = new IndexConstruction();
            ic.init(td.getTrussness());
            ic.work();
            //System.out.println("ic finished.");
            
            Date end = new Date();
            
            System.out.print("| " + filePrint[s] + "\t|");
            System.out.print("| " + vertex[s] + "\t|");
            System.out.print("| " + edge[s] + "\t|");
            String dm = "" + maxDegree;
            if (maxDegree < 10000) {
            	dm = dm + "\t";
			}
            System.out.print("| " + dm + "\t|");
            
            Test tt = new Test();
            String[] kInfo = tt.getKAnalysis(td.getTrussness()).split(",");
            System.out.print("| " + kInfo[0] + "\t|");
            System.out.print("| " + kInfo[1] + "\t\t|");
            
            System.out.print("| " + ic.getEquiTruss().size() + "\t\t|");
            
            String[] maxInfo = tt.getMaxCommunity(ic.getContent(), files[s]).split(",");
            if (maxInfo[0].length() < 5) {
				maxInfo[0] = maxInfo[0] + "\t";
			}
            System.out.print("| " + maxInfo[0] + "\t|");
            System.out.print("| " + maxInfo[1] + "\t\t|");
            
            DecimalFormat df = new DecimalFormat("#.0");
            Long time1 = mid.getTime() - start.getTime();
            Long time2 = end.getTime() - mid.getTime();
            System.out.print("| " + df.format(time1/1000.0) + " s\t|");
            System.out.print("| " + df.format(time2/1000.0) + " s\t|");
            System.out.println();
            
            CommunitySearch cs = new CommunitySearch();
            cs.init(ic.getEquiTruss(), ic.getContent(), ic.getH(), ic.getK_ness());
            //System.out.println("cs initialized.");
            
            s++;
		}
    	
    	
    	System.out.println("| Network \t|| match\t|| cost time\t|");
    	int ss = 0;
        while (ss < 5) {
        	ReadData readData = new ReadData();
    		readData.setVertex(vertex[ss]);
    		readData.setEdge(edge[ss]);
        	String file = "./data/" + files[ss] + ".ungraph.txt";
    		int[][] graph = readData.getGraph(file);
        	
    		Date start = new Date();
    		
            TrussDecomposition td = new TrussDecomposition();
            td.init(graph);
            td.work();
            
            IndexConstruction ic = new IndexConstruction();
            ic.init(td.getTrussness());
            ic.work();
            
            CommunitySearch cs = new CommunitySearch();
            cs.init(ic.getEquiTruss(), ic.getContent(), ic.getH(), ic.getK_ness());
            
            Date mid = new Date();
            
            int count = 0;
            boolean flag = false;
            Set<Integer> vers = new HashSet<Integer>();
            String fileCommu = "./data/" + files[ss] + ".top5000.cmty.txt";
            List<List<Integer>> communities = readData.getCommunity(fileCommu);
            for (List<Integer> community : communities) {
            	flag = false;
				for (int k = community.size(); k > 2; k--) {
					int q = community.get(0);
					cs.work(q, k);
					List<List<List<Integer>>> results = cs.getCommunities();
					vers.clear();
					for (List<List<Integer>> result : results) {
						for (List<Integer> e : result) {
							vers.add(e.get(0));
							vers.add(e.get(1));
						}
						
					}
					
					int j;
					for (j = 0; j < community.size(); j++) {
						if (!vers.contains(community.get(j))) {
							break;
						}
					}

					if (j == community.size()) {
						count++;
						break;
					}
					
				}
			}
            
            Date end = new Date();
            
            System.out.print("| " + filePrint[ss] + "\t|");
            System.out.print("| " + count + "\t\t|");
            DecimalFormat df = new DecimalFormat("#.0");
            Long time = end.getTime() - mid.getTime();
            System.out.print("| " + df.format(time/1000.0) + " s\t|");
            System.out.println();
        	
        	ss++;
    	}
        
    }
}