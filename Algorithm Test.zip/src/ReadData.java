import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class ReadData {
	private int vertex = 100;
	private int edge = 100;
	
	public int[][] getGraph(String fileName){
		int[][] graph = new int[edge][2];
		String line;
		String[] splits;
		
		try {
			BufferedReader reader = new BufferedReader(new FileReader(fileName));
			line = reader.readLine();
			
			int num = 0;
			while (line != null && num < edge) {
				if (line.indexOf("#") != -1) {
					continue;
				}
				
				splits = line.split("[ \t]");
				graph[num][0] = Integer.parseInt(splits[0]);
				graph[num][1] = Integer.parseInt(splits[1]);
				num++;
				line = reader.readLine();
			}
			
			reader.close();
		} catch (FileNotFoundException e) {
			System.err.print(e);
		} catch (IOException e) {
			System.err.print(e);
		}

		return graph;
	}
	
	
	public List<List<Integer>> getCommunity(String fileName) {
		List<List<Integer>> result = new ArrayList<List<Integer>>();
		String line;
		String[] splits;
		
		try {
			BufferedReader reader = new BufferedReader(new FileReader(fileName));
			line = reader.readLine();
			
			while (line != null) {
				splits = line.split("\t");
				List<Integer> lines = new ArrayList<Integer>();
				for (int i = 0; i < splits.length; i++) {
					lines.add(Integer.parseInt(splits[i]));
				}
				result.add(lines);
				
				line = reader.readLine();
			}
			
			reader.close();
		} catch (FileNotFoundException e) {
			System.err.print(e);
		} catch (IOException e) {
			System.err.print(e);
		}
		
		return result;
	}
	
	
	public int[] computeDegree(int[][] graph) {
		Map<Integer, Integer> degree = new HashMap<Integer, Integer>();
		int[] degreeSort = new int[vertex];
		int temp;
		
		for (int i = 0; i < graph.length; i++) {
			if (degree.containsKey(graph[i][0])) {
				temp = degree.get(graph[i][0]);
				degree.remove(graph[i][0]);
				degree.put(graph[i][0], temp+1);
			}
			else {
				degree.put(graph[i][0], 1);
			}
			
			if (degree.containsKey(graph[i][1])) {
				temp = degree.get(graph[i][1]);
				degree.remove(graph[i][1]);
				degree.put(graph[i][1], temp+1);
			}
			else {
				degree.put(graph[i][1], 1);
			}
			
		}
		
		int pos = -1;
		for (Entry<Integer, Integer> entry : degree.entrySet()) {
			temp = pos; 
			while (true) {
				if (pos < 0 || entry.getValue() >= degree.get(degreeSort[pos])) {
					degreeSort[pos+1] = entry.getKey();
					break;
				}
				else {
					degreeSort[pos+1] = degreeSort[pos];
					pos--;
				}
			}
			pos = temp + 1;
		}
		
		return degreeSort;
	}
	
	
	public int getMaxDegree(int[][] graph) {
		Map<Integer, Integer> degree = new HashMap<Integer, Integer>();
		int temp;
		
		for (int i = 0; i < graph.length; i++) {
			if (degree.containsKey(graph[i][0])) {
				temp = degree.get(graph[i][0]);
				degree.remove(graph[i][0]);
				degree.put(graph[i][0], temp+1);
			}
			else {
				degree.put(graph[i][0], 1);
			}
			
			if (degree.containsKey(graph[i][1])) {
				temp = degree.get(graph[i][1]);
				degree.remove(graph[i][1]);
				degree.put(graph[i][1], temp+1);
			}
			else {
				degree.put(graph[i][1], 1);
			}
			
		}
		
		int max = 0;
		for (Entry<Integer, Integer> entry : degree.entrySet()) {
			if(entry.getValue() > max)
				max = entry.getValue();
		}
		
		return max;
	}
	
	
	public int getVertex() {
		return vertex;
	}


	public void setVertex(int vertex) {
		this.vertex = vertex;
	}


	public int getEdge() {
		return edge;
	}


	public void setEdge(int edge) {
		this.edge = edge;
	}
	

}
