package timeflow.data.db.filter;

public interface ValueFilter {
	public boolean ok(Object o);
}
