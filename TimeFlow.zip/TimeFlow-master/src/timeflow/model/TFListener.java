package timeflow.model;

public interface TFListener {
	public void note(TFEvent e);
}
