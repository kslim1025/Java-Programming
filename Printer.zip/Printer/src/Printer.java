abstract class Printer{
	String modelName;
	String manuFactureCom;
	String interFace;
	int printPaperNum;
	int resPaperNumber;
	abstract public void println();
	abstract public void empty();
}

public Printer

public class Printer 
{
public static void main(String argc[])
	{
	
	}
}
