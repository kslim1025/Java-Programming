import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

class ButtonTextHandler implements ActionListener
{
	JTextArea textArea;
	
	public ButtonTextHandler(JTextArea area)
	{
		textArea=area;
	}
	public void actionPerformed(ActionEvent e)
	{
		textArea.setText("All text deleted\n");
		textArea.append("원하는 내용을 입력하세요.\n");
	}
}

public class JTextAreaScrollAdded {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		JFrame frm = new JFrame("JTextArea");
		frm.setBounds(120,120,250,270);
		frm.setLayout(new FlowLayout());
		
		JTextArea textArea =new JTextArea(10,20);
		textArea.append("원하는 내용을 입력하세요.\n");
		textArea.setCaretPosition(textArea.getText().length());
		
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);
		
		JButton btn= new JButton("Clear");
		btn.addActionListener(new ButtonTextHandler(textArea));
		
		JScrollPane simpleScroll= new JScrollPane(textArea);
		frm.add(simpleScroll);
		frm.add(btn);
		
		frm.setVisible(true);
		frm.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		
	}

}
