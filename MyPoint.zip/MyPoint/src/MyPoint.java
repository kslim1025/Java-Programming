abstract class Point{
	int x;
	int y;
	public Point(int x, int y)
	{
		this.x=x;
		this.y=y;
	}
	protected abstract void move(int x, int y);
	protected abstract void reverse();
	protected void show()
	{
		System.out.println(x+","+y);
	}
}

class ColorPoint extends Point{
	String color;
	
	public ColorPoint(int x, int y, String color){
		super (x,y);
		this.color=color;
	}
	protected void move(int x, int y)
	{
		this.x= x;
		this.y= y;
	}
	protected void reverse()
	{
		int temp;
		
		temp =x;
		x=y;
		y=temp;
	}
	protected void show()
	{
		super.show();
		System.out.println(","+color);
	}
}
public class MyPoint {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Point p = new ColorPoint(2,3,"blue");
		p.move(3, 4);
		p.reverse();
		p.show();
	}

}
