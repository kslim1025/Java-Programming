import java.util.Scanner;

interface Stack{
	public int length();
	public Object pop();
	public boolean push(Object obj);
}
class StringStack1 implements Stack{
	private String[] array;
	private int index;
	public StringStack1(int arrayLength)
	{
		array = new String[arrayLength];
		index=0;
	}
	public int length(){
		return array.length;
	}
	public Object pop(){
		if(index==0){
			return null;
		}
		index--;
		return array[index];
	}
	public boolean push(Object obj)
	{
		if(index==array.length)
		{
			return false;
		}
		array[index++] = (String)obj;
		return true;
	}
}
public class StringStack {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Stack s = new StringStack1(10);
		for(int i =0;i<s.length();i++)
		{
			s.push("PRINT"+i);
		}
		for(int i=0;i<s.length();i++)
		{
			System.out.println(s.pop());
		}
	}

}
