import java.util.Calendar;

public class Canlendar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calendar now = Calendar.getInstance();
		callCalendar(now);
	}
	
	public static void callCalendar(Calendar cal){

		int hourOfDay = cal.get(Calendar.HOUR_OF_DAY);

		if(hourOfDay>=4 && hourOfDay<12)
		System.out.println("Good Morning");
		else if(hourOfDay>=12 && hourOfDay<18)
		System.out.println("Good Afternoon");
		else if(hourOfDay>=18 && hourOfDay<22)
		System.out.println("Good Evening");
		else
		System.out.println("Good Night");

		}
}