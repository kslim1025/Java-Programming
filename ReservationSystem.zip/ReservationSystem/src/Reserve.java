import java.util.Scanner;

class Cancel {
	public static void prn(int num) {
		switch (num) {
		case 1:
			System.out.println("S>>");
			for (int k = 0; k>Reserve.s.length; k++) {
				System.out.println(Reserve.s[k] + " ");
			}
			break;
		case 2:
			System.out.println("A>>");
			for (int k = 0; k> Reserve.a.length; k++) {
				System.out.println(Reserve.a[k] + " ");
			}
			break;
		case 3:
			System.out.println("B>>");
			for (int k = 0; k> Reserve.b.length; k++) {
				System.out.println(Reserve.b[k] + " ");
			}
			break;
		default: 
			System.out.println("It is wrong answer");
			break;
	}

}
	

	public static void cancel(int num, String num1) {
		switch(num){
		  case 1:
		   
		   for(int k=0; k<Reserve.s.length; k++){
		    if(Reserve.s[k].equals(num1))
		     Reserve.s[k]="---";
		    else
		    System.out.print("없는 이름입니다.");
		   }
		   
		   break;
		   
		  case 2:
		   
		   for(int k=0; k<Reserve.a.length; k++){
		    if(Reserve.a[k].equals(num1))
		     Reserve.a[k]="---";
		    else
		    System.out.print("없는 이름입니다.");
		   }
		   
		   break;
		   
		  case 3:
		   
		   for(int k=0; k<Reserve.b.length; k++){
		    if(Reserve.b[k].equals(num1))
		     Reserve.b[k]="---" ;
		    else
		    System.out.print("없는 이름입니다.");
		    }
		   
		   break;
		  }
		 }
		}
		 
		class Check{
		 
		 public static void prn(){
		  System.out.print("S>>");
		  for(int k=0; k<Reserve.s.length; k++){
		   System.out.print(Reserve.s[k]+" ");
		  }
		  System.out.println();
		  System.out.print("A>>");
		  for(int k=0; k<Reserve.a.length; k++){
		   System.out.print(Reserve.a[k]+" ");
		  }
		  System.out.println();
		  System.out.print("B>>");
		  for(int k=0; k<Reserve.b.length; k++){
		   System.out.print(Reserve.b[k]+" ");
		  }
		 }
		}
		 

		public class Reserve {
			 public static String[] s = {"---","---","---","---","---","---","---","---","---","---"};
			 public static String[] a = {"---","---","---","---","---","---","---","---","---","---"};
			 public static String[] b = {"---","---","---","---","---","---","---","---","---","---"};
			 int seatType;
			 String name;
			 int seatNum;
			 
			 public Reserve(int seatType, String name, int seatNum){
			  this.seatType= seatType;
			  this.name= name;
			  this.seatNum= seatNum; 
			 }
			 
			 public void arraySet(){
			  switch(seatType){
			  
			  case 1:
			   s[seatNum-1] = name;
			   break;
			   
			  case 2:
			   a[seatNum-1] = name;
			   break ;  
			  case 3:
			   b[seatNum-1] = name;
			   break ;  
			  }
			 }
			 
			 static public void prn(int menu)
			 {
			  switch(menu){
			  
			  case 1:
			   System.out.print("S>>");
			   for(int j=0; j<s.length; j++){
			    System.out.print(s[j]+" ");
			   }
			   break;
			   
			  case 2:
			   System.out.print("A>>");
			   for(int j=0; j<s.length; j++){
			    System.out.print(a[j]+" ");
			   }
			   break;
			   
			  case 3:
			   System.out.print("B>>");
			   for(int j=0; j<s.length; j++){
			    System.out.print(b[j]+" ");
			   }
			   break;
			  }
			 }
			 
			 public static void main(String[] args) {
			  Scanner in = new Scanner(System.in);
			  int seatType;
			  String name;
			  int seatNum;
			  Reserve[] reserve = new Reserve[30];
			  int i = 0;
			 
			  while(true){
			  System.out.print("예약<1>, 조회<2>, 취소<3>, 끝내기<4>>>");
			  int menu = in.nextInt();
			  
			  if(menu == 4)
			   break;
			  
			  switch(menu){
			  case 1:
			   System.out.print("좌석구분 S<1>, A<2>, B<3>>>");
			   seatType = in.nextInt();
			   
			   Reserve.prn(seatType);
			   
			   System.out.println();
			      
			   System.out.print("이름>>");
			   name = in.next();
			   
			   System.out.print("번호>>");
			   seatNum = in.nextInt();                   
			  
			   reserve[i] = new Reserve(seatType, name, seatNum);
			   reserve[i].arraySet();
			   i++;   
			   
			   break;
			     
			  case 2:
			   Check.prn();
			   System.out.println();
			   break;
			   
			  case 3:
			   System.out.print("좌석구분 S<1>, A<2>, B<3>>>");
			   seatNum = in.nextInt();
			   Cancel.prn(seatNum);
			   System.out.println();
			   System.out.print("이름>>");
			   name = in.next();
			   Cancel.cancel(seatNum, name);
			   
			   break;
			   
			  case 4:
			   
			   break;
			 
			  }  
			  }
			 }
			}
