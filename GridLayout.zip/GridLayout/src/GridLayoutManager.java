import java.awt.*;
import javax.swing.*;

public class GridLayoutManager 
{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame frm = new JFrame("GridLayoutManager");
		frm.setBounds(120,120,400,400);
		frm.setLayout(new GridLayout(3,2));
		
		frm.add(new JButton("One"));
		frm.add(new JButton("Two"));
		frm.add(new JButton("Three"));
		frm.add(new JButton("Four"));
		frm.add(new JButton("Five"));
		frm.add(new JButton("Six"));
		frm.setVisible(true);
	}
}
