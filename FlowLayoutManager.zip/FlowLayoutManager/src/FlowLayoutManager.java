import java.awt.*;
import javax.swing.*;

public class FlowLayoutManager {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame frm= new JFrame("FlowLayout Test");
		frm.setBounds(120,120,300,400);
		frm.setLayout(new FlowLayout());
		
		frm.add(new JButton("안녕!!"));
		frm.add(new JButton("I like Swing"));
		frm.add(new JButton("Im a button"));
		
		frm.add(new LargeButton("Hi"));
		frm.add(new LargeButton("I like Swing"));
		frm.add(new LargeButton("Im a button"));
		frm.setVisible(true);
	}
}
class LargeButton extends JButton
{
	public LargeButton(String str)
	{
		super(str);
	}
	
	public Dimension getPreferredSize()
	{
		Dimension largeBtmSz=new Dimension(super.getPreferredSize().width+30,
				super.getPreferredSize().height+15);
	return largeBtmSz;
  }
}
