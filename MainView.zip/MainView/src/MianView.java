import java.awt.GridLayout;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
 
public class MianView extends JFrame {
 
    TextPanel tp = new TextPanel();
    
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        new MianView();
    }
 
    public MianView() {
 
        //TextPanel tp = new TextPanel();
        BtnPanel bp = new BtnPanel();
        this.setTitle("데이터베이스_report");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(600, 600);
        this.setVisible(true);
        setLayout(new GridLayout(1, 2));
 
        add(tp);
        add(bp);
        this.pack();
    }
 
    class TextPanel extends JPanel {
        TextField id = new TextField(10);
        TextField name = new TextField(10);
        TextField count = new TextField(10);
        TextField price = new TextField(10);
        TextField gdate = new TextField(10);
 
        String date;
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss MM/dd/yy");
        public TextPanel() {
            // TODO Auto-generated constructor stub
            setLayout(new GridLayout(5, 2));
            add(new Label("제품I D:"));
            add(id);
            add(new Label("제 품 명:"));
            add(name);
            add(new Label("제품가격:"));
            add(price);
            add(new Label("제품갯수:"));
            add(count);
            add(new Label("입고일:"));
            date = sdf.format(new Date());
            gdate.setText(date);
            add(gdate);
        }
    }
 
    class BtnPanel extends JPanel {
        JButton btnInsert = new JButton("추가");
        //TextPanel t = new TextPanel();
		protected Connection conn;
		protected Statement stmt;
		protected ResultSet ResultSetrs;
		protected Object Connectionconn;
		protected Object Statementstmt;
        
        public BtnPanel() {
            // TODO Auto-generated constructor stub
            btnInsert.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) 
                {
                    // TODO Auto-generated method stub
                    String id_tmp = tp.id.getText();
                    String name_tmp = tp.name.getText();
                    int count_tmp = Integer.parseInt(tp.count.getText());
                    int price_tmp = Integer.parseInt(tp.price.getText());
                    
                    if (id_tmp.equals("") || name_tmp.equals("")||tp.count.equals("") || tp.price.equals(""))
                    {
                        JOptionPane.showMessageDialog(null, "빈공간을 채워주세요","Insert_Error", JOptionPane.ERROR_MESSAGE);
                    } 
                    else 
                    {
                        Connectionconn =null;
                        Statementstmt= null;
                        int rst = 0;
                        try {
                        		Class.forName("com.mysql.jdbc.Driver");
                        		conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/reportdb","root", "wither10");
                        		System.out.println("DB 연결 완료");
                        		stmt= conn.createStatement();
                        		ResultSetrs= stmt.executeQuery("select * from Products");
                        		rst= stmt.executeUpdate("insert into Products(id,name,price,cs,getdate) " + "values('" + id_tmp + "','"+ name_tmp + "','"+ price_tmp+ "','" + count_tmp+ "','"+ tp.date + "')");
                        	}
                        		catch (ClassNotFoundException e1) 
                        			{
                        				System.out.println("JDBC 드라이버 로드 에러");
                        				}
                        				catch (Exception e1) 
                        				{
                        					System.out.println("DB 연결 실패");
                        				}
                    		}
                }
            });
            add(btnInsert);
        }
    }
}
