import java.util.Scanner;

public class ExChangeMoney {
	public static void main(String args[]){
		int[] unit={50000, 10000, 1000, 500, 100, 50, 10, 1};
		int count[] = new int[8];
		
		String str1="원권",str2 = "매", str3="원짜리 동전", str4="개";
		Scanner src= new Scanner(System.in); //입력받은 돈을 스캔 
		
		int money= src.nextInt();//스캔 받은 돈을 넣는다  
		
		for(int i=0;i<unit.length;i++)
		{
			count[i]=money/unit[i];
			money= money % unit[i];
			
			if(i<3)
			{
				System.out.println(unit[i]+str1+count[i]+str2);
			}
			else
			{
				System.out.println(unit[i]+str3+count[i]+str4);
			}
		}
	}
}
