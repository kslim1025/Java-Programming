import java.util.Scanner;

public class TwoPointSquare {
	public static void main(String args[])
	{
		int x,y;
		System.out.println("We need to insert x,y point\n");
		Scanner scn= new Scanner(System.in);
		
		x= scn.nextInt();
		y= scn.nextInt();
		
		if(x>=50 && x<=100)
		{
			if(y>=50 && y<=100)
			{
				System.out.println("이것은 네모 안에 속한다.");
			}
		}
		else{
			System.out.println("네모안에 점이 없습니다.");
		}
	}
}
