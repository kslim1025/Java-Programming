package Logic;

/**
 * Created by hadoop on 1/11/18.
 */
public class Format {
}
