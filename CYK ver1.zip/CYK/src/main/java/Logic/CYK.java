package Logic;

import Util.P;

import java.util.ArrayList;

/**
 * Created by hadoop on 1/12/18.
 */
public class CYK {



    //根据输入的字符串 判断其归属
    public static String getFrom(String a, P[] p) {


        String txt ="";

        for (int i = 0; i < p.length; i++) {

            if (p[i].right.contains("|")) {

                String pp[] = p[i].right.toString().split("\\|");

                for (String pps : pp) {


                   // System.out.println("=="+pps);
                    if (pps.equals(a)) {
                        txt += p[i].left + " ";
                        break;

                    }
                }

            } else {

                if (p[i].right.toString().equals(a)) {

                    txt += p[i].left + " ";
                }

            }


        }

        return txt;

}


//根据字符串进行排列组合1

    public static  ArrayList<String> lists(String txt){

        ArrayList<String>  al=new ArrayList<String>();


        String a[]=txt.split("");

        String tmp1="";
        for(int i=0;i<a.length;i++){

            tmp1+=a[i];

            String tmp2="";
            for(int j=i+1;j<a.length;j++){


                tmp2+=a[j];

            }

            al.add(tmp1);
            al.add(tmp2);


        }

        return al;


    }

//根据字符串进行排列组合2

    public static  ArrayList<String> list2s(String txt, String txt2){

        ArrayList<String>  al=new ArrayList<String>();


        String a[]=txt.split(" ");
        String b[]=txt2.split(" ");

        for(int i=0;i<a.length;i++)
        {
            for(int j=0;j<b.length;j++){

                al.add(a[i]+b[j]);

            }
        }
        return al;


    }


    public  static  String[][]  cyk( String txt,P[] p){


        String S[]=txt.split("");

        String T[][]=new String[S.length+1][S.length+1];

        System.out.println(S.length);

        //先给表格第一行赋值

        for(int i=0;i<S.length;i++){

            T[1][i+1]=getFrom(S[i],p);
        }


        for(int i=2;i<=S.length;i++){

            System.out.println("==================计算表格======行数=="+i);


       //作为增量控制column的变化
            int k=i;


            for(int j=1;j<=S.length-k+1;j++){


                String tmp2="";

                for(int h=1;h<k;h++){

                    System.out.println(i+"  "+h+" "+j+" "+T[h][j] + "==" + (i-h)+" "+(j+h)+"  "+T[i - h][j + h]);

                    if(T[i-h][j+h]!=null&&T[h][j]!=null) {

                        ArrayList<String> al = list2s(T[h][j], T[i - h][j + h]);
                      //  System.out.println(T[h][j] + "====" + T[i - h][j + h]);


                        for (int s = 0; s < al.size(); s++) {

                            String t= getFrom(al.get(s), p);

                            if(!tmp2.contains(t)) {
                                tmp2 += t+ " ";

                            }

                        }

                    }
                }



                T[i][j]=tmp2;
                System.out.println(i+" "+j+":"+tmp2);
            }
        }



//        for(int m=1;m<=S.length;m++){
//
//            for(int n=1;n<=S.length;n++){
//
//
//                System.out.print(T[m][n]+"||");
//
//            }
//
//            System.out.println();
//        }


        return T;

    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub




        P[] p = new P[4];

        p[0]=new P(); p[0].left="S"; p[0].right="AB|BC";
        p[1]=new P(); p[1].left="A"; p[1].right="BA|a";
        p[2]=new P(); p[2].left="B"; p[2].right="CC|b";
        p[3]=new P(); p[3].left="C"; p[3].right="AB|a";




       String S[][]= cyk("baaba",p);


        System.out.println(getFrom("a",  p));


//        for(int m=1;m<=5;m++){
//
//            for(int n=1;n<=5;n++){
//
//
//                System.out.print(S[m][n]+"          |");
//
//            }
//
//            System.out.println();
//        }


    }


}
