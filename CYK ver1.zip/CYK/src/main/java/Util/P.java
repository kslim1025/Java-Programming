package Util;

/**
 * Created by hadoop on 1/10/18.
 */
public class P {

        public P() {
            left = new String();
            right = new String();
        }

        public String left;
        public String right;

}
