package Util;

import java.util.Scanner;

/**
 * Created by hadoop on 1/10/18.
 */
public class Chmosky {



    static public String flag="";

    /**
     * @param args
     */
    public static void main(String[] args) {
        int n;
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入文法产生式的个数：");
        n = scanner.nextInt();
        String inputString;
        P[] p = new P[n];

        for (int k = 0; k < p.length; k++) {
            inputString = scanner.next();
            String temp = inputString.trim();
            p[k] = new P();
            p[k].left = inputString.split("->")[0];
            p[k].right = temp.split("->")[1];

        }
        scanner.close();
        Third(p);


    }

    public static boolean Zero(P[] p) {//
        int i, j;
        for (i = 0; i < p.length; i++) // 循环n次，即遍历所有产生式
        {
            for (j = 0; j < p[i].left.length(); j++) // 遍历产生式左部每一个字符
            {
                if (p[i].left.charAt(j) >= 'A' && p[i].left.charAt(j) <= 'Z') // 判断字符是否是非终结符
                    break;
            }
            if (j == p[i].left.length()) {

                flag="该文法不是0型文法";

                System.out.println("该文法不是0型文法");
                return false;
            }
        }
        if (i == p.length)
            return true;// 如果每个产生时都能找到非终结符
        return false;
    }

    public static boolean First(P[] p) {
        int i;
        if (Zero(p)) {
            for (i = 0; i < p.length; i++) {
                if ((p[i].left.length() > p[i].right.length())
                        && p[i].right.length() != 0) // 判断产生式左部长度是否大于右部
                    break;
            }
            if (i == p.length)
                return true;
            else {
                flag="0型文法";
                System.out.println("0型文法");
                return false;
            }
        } else
            return false;

    }

    public static boolean Second(P[] p) {
        int i;
        if (First(p)) // 同上，先判断低级文法是否成立
        {
            for (i = 0; i < p.length; i++) // 同上，遍历所有文法产生式
            {
                if ((p[i].left.length() != 1)
                        || !(p[i].left.charAt(0) >= 'A' && p[i].left.charAt(0) <= 'Z'))
                    break;
            }
            if (i == p.length)
                return true;
            else {
                flag="1型文法";
                System.out.println("1型文法");
                return false;
            }
        } else
            return false;

    }

    public static void Third(P[] p) // 判断3型文法
    {
        int i;
        if (Second(p)) // 同上，先判断是否是2型文法
        {
            for (i = 0; i < p.length; i++) // 同上，遍历文法所有的产生式
            {
                if ((p[i].right.length() == 0)
                        || (p[i].right.length() >= 3)
                        || (p[i].right.charAt(0) >= 'A' && p[i].right.charAt(0) <= 'Z')) // 判断产生式右部字符个数是否在12之间，判断右部第一个字符是否是非终结符
                    break;
            }
            if (i == p.length) {
                for (i = 0; i < p.length; i++) {
                    if (p[i].right.length() == 2) {
                        if (!(p[i].right.charAt(1) >= 'A' && p[i].right
                                .charAt(1) <= 'Z'))
                            break;
                    }
                }
                if (i == p.length) {

                    flag="该文法属于3型文法";
                    System.out.println("该文法属于3型文法");
                } else

                    flag="该文法属于2型文法";
                    System.out.println("该文法属于2型文法");

            }
            else

                flag="该文法属于2型文法";
                System.out.println("该文法属于2型文法");
        } else

           // flag="end";
            System.out.println("END");
    }



}
