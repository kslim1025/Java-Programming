package Interface;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import Logic.CYK;
import Util.Chmosky;
import Util.P;

/**
 * Created by hadoop on 1/10/18.
 */
public class CykInterface1  extends JFrame implements ActionListener {

    private JPanel jp1,jp2,jp3;

    private JLabel jl1,jl2,jl3,jl4,jl5;
    private JTextField jf1,jf2,jf3,jf4,jf5;

    private JButton jb1, jb2;

    private JTextArea     jTextArea;

    public Chmosky cs = new Chmosky();

    public CykInterface1(){


        jp1=new JPanel();
        jp2=new JPanel();
        jp3=new JPanel();


        jl1=new JLabel("N 非终结符: ");//asdsdghkhkkhkhkhhhkhhhkhkhh
        jl2=new JLabel("T 终结符: ");
        jl3=new JLabel("P 产生式: ");
        jl4=new JLabel("S 开始符: ");
        jl5=new JLabel("输入字符串: ");

        jf1=new JTextField("");
        jf2=new JTextField("");
        jf3=new JTextField("");
        jf4=new JTextField("");
        JScrollPane jsp=new JScrollPane(jf3);

        jf5=new JTextField("");

        // 设置标题栏内容
        setTitle("cyk算法  判断上下文无关文法");
        // 设置初始化窗口位置
        setBounds(100, 100, 800, 800);
        // 设置窗口布局
       // setLayout(new FlowLayout());
        // 创建按钮对象
        jb1 = new JButton("开始判断");
        // 将按钮添加事件监听器
        jb1.addActionListener(this);
        // 创建按钮对象
        jb2 = new JButton("弹窗");
        // 将按钮添加事件监听器
        jb2.addActionListener(this);
        // 把按钮容器添加到JFrame容器上

        jp1.add(jl1);
        jp1.add(jf1);
        jp1.add(jl2);
        jp1.add(jf2);
        jp1.add(jl3);
        jp1.add(jsp);
        jp1.add(jl4);
        jp1.add(jf4);
        jp1.add(jl5);
        jp1.add(jf5);

        jp1.add(jb1);
        jp1.add(jb2);


        jp1.setPreferredSize(new Dimension(100,100));



        jTextArea=new JTextArea("cyk  算法");


        jTextArea.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) {


            }

            public void removeUpdate(DocumentEvent e) {

            }

            public void changedUpdate(DocumentEvent e) {

            }
        });


        jp2.add(jTextArea);


        jp1.setLayout(new GridLayout(3,2,5,5 ));
        jp2.setLayout(new FlowLayout());
        add(jp1,BorderLayout.NORTH);
        add(jp2,BorderLayout.CENTER);



        // 设置窗口可视化
        setVisible(true);
        // 设置窗口关闭
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }








    public void actionPerformed(ActionEvent e) {
        // 判断最初发生Event事件的对象
        if (e.getSource() == jb1) {
            // 获得容器
            Container c = getContentPane();
            // 设置容器背景颜色
            c.setBackground(Color.blue);


            String N=jf1.getText();
            String T=jf2.getText();
            String P=jf3.getText();
            String S=jf4.getText();
            String txt=jf5.getText();

            String Ns[]=N.split(" ");
            String Ts[]=T.split(" ");
            String ps[]=P.split(" ");


            P p[] = new P[ps.length];

            String pss="";
            for(int i=0;i<p.length;i++){

                System.out.println(ps[i]+"=="+p.length);
                p[i]=new P();
                p[i].left=ps[i].split("\\-\\>")[0];
                p[i].right=ps[i].split("\\-\\>")[1];

                pss+= p[i].left+"->"+ p[i].right;
            }

            cs.Third(p);


            String TT[][]=CYK.cyk(txt,p);


            String display="";


            for(int m=1;m<=5;m++){

                for(int n=1;n<=5;n++){


                    display+=TT[m][n]+"|";

                   // System.out.print(S[m][n]+"||");

                }



               // System.out.println();
            }



                    if(cs.flag.equals("该文法属于2型文法")){

                        jTextArea.setRows(50);
                        jTextArea.setColumns(40);
                        jTextArea.setText(display);

                        jp2.add(jTextArea);
                        jp2.setLayout(new FlowLayout());
                        add(jp2,BorderLayout.CENTER);



                        // 设置窗口可视化
                        setVisible(true);
                        // 设置窗口关闭
                        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    }

                    else{

                        // 创建JDialog窗口对象
                        JDialog dialog = new JDialog();
                        dialog.setBounds(300, 200, 100, 100);

                        dialog.setVisible(true);
                    }


        }
        else if (e.getSource() == jb2) {
            // 创建JDialog窗口对象
            JDialog dialog = new JDialog();
            dialog.setBounds(300, 200, 100, 100);

            dialog.setVisible(true);
        }
    }


    public static void main(String args[]){

        new CykInterface1();
    }
}
